
package banco;


public class Banco {
    public static int qtdConta;
    public static boolean dinheiro;
    public static int qtdCliente;
    public static String nacionalidade;
    public static String nutransacoes;
        
}
