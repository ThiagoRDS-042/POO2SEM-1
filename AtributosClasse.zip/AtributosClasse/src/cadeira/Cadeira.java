
package cadeira;



public class Cadeira {
    public static int qtdpes;
    public static String datadcomprar;
    public static int qtdcadeira;
    public static String cor;
    public static String material;
}
