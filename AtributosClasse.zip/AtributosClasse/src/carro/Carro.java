
package carro;



public class Carro {
    public static int nubancos;
    public static String fabricacao;
    public static String marca;
    public static int nupineus;
    public static String modelo;
}
