
package principal;
import carro.Carro;
import sala.Sala;

public class Principal {
    public static void main(String[] args) {
    Carro a1= new Carro();
    Carro a2= new Carro();
        System.out.println("Carro");
        a1.nubancos=5;
        a1.fabricacao = "17.04.2019";
        a1.marca = "fiat";
        a1.nupineus=5;
        a1.modelo="Siena";
        System.out.println(a1.marca+" "+a1.modelo+" "+a1.fabricacao+" "+a1.nubancos+" "+a1.nupineus);
        System.out.println(a2.marca+" "+a2.modelo+" "+a2.fabricacao+" "+a2.nubancos+" "+a2.nupineus);
        System.out.println("Sala de aula");
        Sala s1 = new Sala();
        Sala s2 = new Sala();
        s1.qtddeportas="1";
        s1.qtdaluno=45;
        s1.qtdmesa=1;
        s1.qtdcarteiras=46;
        s1.deficiente=true;
        System.out.println("qtd portas "+s1.qtddeportas+"  qtd aluno "+s1.qtdaluno+" qtd mesa "+s1.qtdmesa+" qtd carteira "+s1.qtdcarteiras+"  tem deficiente "+s1.deficiente);
        System.out.println("qtd portas "+s2.qtddeportas+"  qtd aluno "+s2.qtdaluno+" qtd mesa "+s2.qtdmesa+" qtd carteira "+s2.qtdcarteiras+"  tem deficiente "+s2.deficiente);
        
        
    }
}
    
