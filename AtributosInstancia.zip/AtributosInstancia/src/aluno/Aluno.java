
package aluno;

public class Aluno {
  public String cpf;
  public String nome;
  public String endereço;
  public String matricula;
  public boolean deficiente;
}
