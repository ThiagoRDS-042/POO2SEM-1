
package animal;

public class Animal {
   public String nome;
   public String tipo;
   public String raça;
   public String sexo;
    public boolean patas;
}
