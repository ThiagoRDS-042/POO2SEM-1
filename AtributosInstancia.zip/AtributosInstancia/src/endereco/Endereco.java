
package endereco;


public class Endereco {
  public String rua;
  public String cidade;
  public String numero;
  public String complemento;
  public String pais;
}
