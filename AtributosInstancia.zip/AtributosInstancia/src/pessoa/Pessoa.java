
package pessoa;


public class Pessoa {
    public String nome;
    public String rg;
    public String cpf;
    public String sexo;
    public String numetelefone;
}
