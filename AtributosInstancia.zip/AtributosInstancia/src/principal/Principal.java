
package principal;

import endereco.Endereco;
import pessoa.Pessoa;


public class Principal {
    public static void main(String[] args) {
        System.out.println("Pessoa");
        Pessoa p1 = new Pessoa();
         Pessoa p2 = new Pessoa();
         p1.nome="João";
         p1.cpf="008.756.789";
         p1.numetelefone="+5588997549896";
         p1.rg="20087898486";
         p1.sexo="Masculino";
         
         p2.nome="Maria";
         p2.cpf="007.653.326";
         p2.numetelefone="+5588996979891";
         p2.rg="20345364789";
         p2.sexo="Feminino";
         
         System.out.println("Nome "+p1.nome+" CPF "+p1.cpf+" Numero "+p1.numetelefone+" RG "+p1.rg+" sexo "+p1.sexo);
    System.out.println("Nome "+p2.nome+" CPF "+p2.cpf+" Numero "+p2.numetelefone+" RG "+p2.rg+" sexo "+p2.sexo);

        System.out.println("Endereço");
         Endereco e1 = new Endereco();
         Endereco e2 = new Endereco();
         e1.cidade="Iguatu";
         e1.rua="Floriano Peixoto";
         e1.numero="104";
         e1.pais="Brasil";
         e1.complemento="Proximo ao Banco Bradesco";
         e2.cidade="Icó";
         e2.rua="Francisco Marciel";
         e2.numero="102";
         e2.pais="Brasil";
         e2.complemento="Proximo a Daniel Chocolate";
         System.out.println("Cidade "+e1.cidade+" rua "+e1.rua+" numero "+e1.numero+" pais "+e1.pais+" complemento "+e1.complemento);
         System.out.println("Cidade "+e2.cidade+" rua "+e2.rua+" numero "+e2.numero+" pais "+e2.pais+" complemento "+e2.complemento);
    }
}
