
package questao01;

import java.util.Scanner;

public class Questao01 {
    public static double media(double a,double b,double c){
         return (a+b+c)/3;
    }
    public static void main(String[] args) {
        System.out.println("Digite 3 Notas");
        Scanner sc = new Scanner(System.in);
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        double c=sc.nextDouble();
        System.out.println("Sua Média é  "+media(a,b,c));
    }
    
}
