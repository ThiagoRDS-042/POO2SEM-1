
package questao02;


public class Questao02 {
    public static int somarVetor(int[] numero){
        int a=0;
   for(int i =0;i<numero.length;i++){
      a+=numero[i];
   }
        return a;
    }
    public static void main(String[] args) {
        int[] numeros ={1,2,3};
        System.out.println(somarVetor(numeros));
    }
}
