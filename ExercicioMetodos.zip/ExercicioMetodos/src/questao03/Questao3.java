/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao03;

import java.util.Scanner;


public class Questao3 {
 public static double horas(double segundo){
double hora =0;
double resto=0;
double minutos=0;
while((segundo-3600)>=0){
    ++hora;
    resto=segundo-3600;
    segundo=resto;
}while(resto-60>=0){
   ++minutos;
   resto=resto-60;
   
}
double segundo2=resto;
     System.out.println(hora+" h "+minutos+" m "+segundo2+" s");
return 0;
}
    public static void main(String[] args) {
        System.out.println("Digite Segundos");
        Scanner sc = new Scanner(System.in);
        double segundo=sc.nextDouble();
        System.out.println(horas(segundo));
                
                }
 
}
