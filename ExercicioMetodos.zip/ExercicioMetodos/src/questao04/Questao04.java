
package questao04;

import java.util.Scanner;


public class Questao04 {
    public static String crescente(int[] a){
        int b=0;
       if(a[0]>a[1]&&a[1]>a[2]){
         b=a[0];
         a[0]=a[2];
         a[2]=b; 
       }else if (a[0]>a[1]&&a[1]<a[2]&&a[0]>a[2]){
           b=a[0];
           a[0]=a[1];
           a[1]=a[2];
           a[2]=b;
       }else if (a[1]>a[0]&&a[0]>a[2]){
           b=a[0];
           a[0]=a[2];
           a[2]=a[1];
           a[1]=b;
       }else if (a[1]>a[0]&&a[0]<a[2]&&a[1]>a[2]){
           b=a[1];
           a[1]=a[2];
           a[2]=b;
           
       }else if (a[2]>a[0]&&a[0]>a[1]){
           b=a[0];
           a[0]=a[1];
           a[1]=b;
       }else if (a[2]>a[0]&&a[0]<a[1]&&a[2]>a[1]){
           a[1]=a[1];
           a[2]=a[2];
           a[0]=a[0];
       }for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
      return "Ordem Crescente";
  
       
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] a=new int[3];
        int i=0;
        for(;i<3;i++){
            a[i]=sc.nextInt();
        }
        System.out.println(crescente(a));
    }
}
