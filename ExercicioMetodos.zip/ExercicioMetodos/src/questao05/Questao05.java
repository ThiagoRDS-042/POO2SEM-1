
package questao05;

import java.util.Scanner;


public class Questao05 {
    public static int maiorMenor(int [] a){
        int maior=a[1];
        int menor = a[1];
        for (int i = 0; i < a.length; i++) {
         if(maior<a[i]){
          maior=a[i];
          
         } if(menor>a[i]){
             menor=a[i];
         }
         
        }
        System.out.println("O Maior "+maior);
        return menor;
        
    }
    public static void main(String[] args) {
        System.out.println("Digite numeros");
        Scanner sc = new Scanner(System.in);
        int [] a=new int [3];
        int i = 0;
        for (; i < 3; ) {
            a[i]=sc.nextInt();
            i++;
        }
        System.out.println("O Menor "+maiorMenor(a));
    }
 
}
