
package questao06;

import java.util.Scanner;

public class Questao06 {
    public static boolean parImpar(int a){
       if(a%2==0){
           System.out.println("Número par");
         return true;  
       }
        System.out.println("Número Impar");
        return false;
       
            }
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Digite Número");
        int a = sc.nextInt();
        System.out.println(parImpar(a));
    }
}
