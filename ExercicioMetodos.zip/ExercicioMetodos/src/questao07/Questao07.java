
package questao07;

import java.util.Scanner;


public class Questao07 {
    public static boolean positivoNegativo(int a){
        if(a<0){
            return false;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite Número");
        int a = sc.nextInt();
        System.out.println(positivoNegativo(a));
    }
}
