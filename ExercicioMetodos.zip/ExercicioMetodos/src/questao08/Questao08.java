
package questao08;

import java.util.Scanner;


public class Questao08 {
    public static String triangulo(int x,int y,int z){
        if(x+y<z||y+z<x||x+z<y){
         return "Não é um Triangulo";   
        }else if(x==y&&y==z){
            return "triangulo Equilátero";
        }else if(x==y||y==z||x==z){
            return "Triãngulo Isósceles";
        }
        return "triangulo Escalenio";
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite Lados do Triangulo");
        int x = sc.nextInt(),y=sc.nextInt(),z=sc.nextInt();
        System.out.println(triangulo(x, y, z));
    }
    
}
